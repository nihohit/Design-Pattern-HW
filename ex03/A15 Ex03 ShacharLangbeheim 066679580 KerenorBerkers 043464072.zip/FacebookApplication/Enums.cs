﻿
namespace FacebookApplication
{
    public enum eFetchOption
    {
        All,
        Friends,
        FriendsLists,
        Inbox,
    }
}
